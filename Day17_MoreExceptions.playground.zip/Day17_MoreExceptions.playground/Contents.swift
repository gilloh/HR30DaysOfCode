import Foundation
import Darwin

// Defining enum for throwing error
// throw RangeError.NotInRange... is used to throw the error
enum RangeError : Error {
  case NotInRange(String)
}

// Start of class Calculator
class Calculator {
  // Start of function power
  func power(n: Int, p: Int) throws -> Int {
    if n < 0 || p < 0 {
      throw RangeError.NotInRange("n and p should be non-negative")
    } else {
      return Int(pow(Double(n), Double(p)))
    }
  }
}

let myCalculator = Calculator()

try myCalculator.power(n: 3, p: 5)
try myCalculator.power(n: 2, p: 4)
try myCalculator.power(n: -1, p: -2)
try myCalculator.power(n: -1, p: 3)
