import Foundation

// Complete the factorial function below.
func factorial(n: Int) -> Int {
  if n <= 0 {
    return 0
  } else if n == 1 {
    return 1
  } else {
    return n * factorial(n: n-1)
  }
}

factorial(n: 3)

