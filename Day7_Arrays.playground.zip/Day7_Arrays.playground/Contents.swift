import Foundation

func reversedArray(_ array: [Int]) -> String {
  var reversed = String()

  for i in array.indices.reversed() {
    reversed.append(Character(String(array[i])))
    reversed.append(" ")
  }

  return reversed
}

let rev = reversedArray([1,2,3,1])



print(rev)
//[].joined()


