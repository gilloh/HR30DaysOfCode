import Foundation

class Node {
  let data: Int
  var next: Node?

  init(data: Int) {
    self.data = data
  }
}

func insert(head: Node?, data: Int!) -> Node? {
  // Enter your code here.

  let newNode = Node(data: data)

  if head == nil {
    return newNode
  } else if head?.next == nil {
      head!.next = newNode
  } else {
    _ = insert(head: head?.next, data: data)
  }
  return head
}

insert(head: insert(head: insert(head: nil, data: 4), data: 3), data: 2)

class NodeN {
  let data: Int
  var next: NodeN?

  init(data: Int) {
    self.data = data
  }
}

func insertN(head: NodeN?, data: Int) -> NodeN? {
  let newNode = NodeN(data: data)

  if head == nil {
    return newNode
  } else if head?.next == nil {
    head!.next = newNode
  } else {
    insertN(head: head?.next, data: data)
  }
  return head
}

insertN(head: insertN(head: insertN(head: nil, data: 4), data: 3), data: 2)





































