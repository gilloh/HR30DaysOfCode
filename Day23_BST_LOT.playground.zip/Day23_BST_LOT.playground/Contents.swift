import Foundation

class Node {
  var data: Int
  var left: Node?
  var right: Node?
  
  init(d : Int) {
    data  = d
  }
}

class Tree {
  func insert(root: Node?, data: Int) -> Node? {
    if root == nil {
      return Node(d: data)
    }
    
    if data <= (root?.data)! {
      root?.left = insert(root: root?.left, data: data)
    } else {
      root?.right = insert(root: root?.right, data: data)
    }
    
    return root
  }
  
  func getHeight(root: Node?) -> Int {
    var leftH = 0
    var rightH = 0
    if root?.left != nil {
      leftH = getHeight(root: root?.left) + 1
    }
    if root?.right != nil {
      rightH = getHeight(root: root?.right) + 1
    }
    return leftH > rightH ? leftH : rightH
  }
  
  func levelOrder(root: Node?) -> Void {
    var queue = [root!]
    
    while !queue.isEmpty {
      var nextQueue: [Node] = []
      
      for node in queue {
        print("\(node.data)", separator: " ")
        if node.left != nil {
          nextQueue.append(node.left!)
        }
        if node.right != nil {
          nextQueue.append(node.right!)
        }
      }
      queue = nextQueue
    }
  } // End of levelOrder function
}

var root: Node?
let tree = Tree()

let t = [3,5,4,7,2,1]

for i in t {
  root = tree.insert(root: root, data: i)
}

print(tree.getHeight(root: root))
tree.levelOrder(root: root)


