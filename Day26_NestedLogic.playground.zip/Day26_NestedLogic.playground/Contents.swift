import Foundation

class RDate {
  let day: Int
  let month: Int
  let year: Int
  
  init(day: Int, month: Int, year: Int) {
    self.day = day
    self.month = month
    self.year = year
  }
}

func calculateFine(returnDate: RDate, pickDate: RDate) -> Int {
  let yearDif = returnDate.year - pickDate.year
  let monthDif = returnDate.month - pickDate.month
  let dayDif = returnDate.day - pickDate.month
  
  if yearDif < 0 {
    return 0
  } else if yearDif == 0 {
    if monthDif <= 0 {
      if dayDif <= 0 {
        return 0
      } else {
        return dayDif * 15
      }
    } else {
      return monthDif * 500
    }
  } else {
    return 10000
  }
}

//let returned = readLine()!.components(separatedBy: " ").map { Int($0)! }
//let deadline = readLine()!.components(separatedBy: " ").map { Int($0)! }
//
//let dateOne = RDate(day: returned[0], month: returned[1], year: returned[2])
//let dateTwo = RDate(day: deadline[0], month: deadline[1], year: deadline[2])

let dateOne = RDate(day: 31, month: 12, year: 2009)
let dateTwo = RDate(day: 1, month: 1, year: 2010)

print(calculateFine(returnDate: dateOne, pickDate: dateTwo))
