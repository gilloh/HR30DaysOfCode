import Foundation

class Solution {

  var stack = [Character]()
  var queue = [Character]()

  func pushCharacter(ch: Character) { stack.append(ch) }
  func popCharacter() -> Character { return stack.removeLast() }

  func enqueueCharacter(ch: Character) { queue.append(ch) }
  func dequeueCharacter() -> Character { return queue.removeFirst() }
}


