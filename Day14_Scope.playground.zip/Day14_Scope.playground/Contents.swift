//import Foundation
//
//func maxDif(a: [Int]) -> Int {
//  var ordA = a
//  ordA = ordA.sorted(by: { $0 < $1 })
//  return ordA[ordA.count-1] - ordA[0]
//}
//
//var a = [6,3,2,1,5,4]
//
//a = a.sorted(by: { $0 < $1 })
//
//print(a)


import Foundation

class Difference {
  private var elements = [Int]()
  var maximumDifference: Int
  // Write your code here
  init(a: [Int]) {
    elements = a
    maximumDifference = 0
  }

  func computeDifference() {
    elements = elements.sorted(by: { $0 < $1 })
    maximumDifference = elements[elements.count - 1] - elements[0]
  }

} // End of Difference class

let n = Int(readLine()!)!
let a = readLine()!.components(separatedBy: " ").map{ Int($0)! }

let d = Difference(a: a)

d.computeDifference()

print(d.maximumDifference)
