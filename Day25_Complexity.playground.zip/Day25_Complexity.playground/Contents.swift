import Foundation

// Enter your code here

func isPrime(x: Int) -> String {
  if x == 2 || x > 1 && !(2...Int(sqrt(Double(x)))).contains { x % $0 == 0 } {
    return "Prime"
  } else {
    return "Not prime"
  }
}

//for _ in 0..<Int(readLine()!)!{
//  print(isPrime(x: Int(readLine()!)!))
//}


isPrime(x: 12)
isPrime(x: 5)
isPrime(x: 7)

isPrime(x: 1000000007)
