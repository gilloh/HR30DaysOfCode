import Foundation

private func bitwiseAND(n: Int, k: Int) -> Int {
  var maxMul = 0
  
  for i in 1 ... n {
    for j in i ..< n {
      if i & (j + 1) < k {
        maxMul = maxMul < i & (j + 1) ? i & (j + 1) : maxMul
      }
    }
  }
  return maxMul
}



guard let t = Int((readLine()?.trimmingCharacters(in: .whitespacesAndNewlines))!)
  else { fatalError("Bad input") }

for _ in 1...t {
  let nk = readLine()!.components(separatedBy: " ").map{ Int($0)! }
  
  print(bitwiseAND(n: nk[0], k: nk[1]))
}
