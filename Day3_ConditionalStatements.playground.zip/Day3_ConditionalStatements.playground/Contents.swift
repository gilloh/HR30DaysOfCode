import Foundation

guard let N = Int((readLine()?.trimmingCharacters(in: .whitespacesAndNewlines))!)
  else { fatalError("Bad input") }

let nPrint = N%2 == 0 && (N>20 || (N >= 2) && (N < 5) ) ? "Not Weird" : "Weird"

print(nPrint)
