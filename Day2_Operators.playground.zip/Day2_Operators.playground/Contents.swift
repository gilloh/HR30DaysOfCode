// Complete the solve function below.
func solve(meal_cost: Double, tip_percent: Int, tax_percent: Int) -> Void {
  let tip = Float(meal_cost) * Float(tip_percent)/Float(100)
  let tax = Float(meal_cost) * Float(tax_percent)/Float(100)

  print(Int(Double(Float(meal_cost) + tip+tax).rounded()))
}

solve(meal_cost: 12, tip_percent: 20, tax_percent: 8)
