import Foundation
//import Darwin
//
//let numStrings = Int(readLine()!)!

func printEvenAndOdd(string: String) {
  // This prints inputString to stderr for debugging:
//  fputs("string: " + string + "\n", stderr)

  var evenString = String()
  var oddString = String()
  
  var p = 0
  
  for i in string.indices {
    p % 2 == 0 ? evenString.append(string[i]) : oddString.append(string[i])
    p+=1
  }
  
  // Print the even-indexed characters
  // Write your code here
  print(evenString + " " + oddString)
  
  // Print a space
//  print(" ", terminator: "")
  
  // Print the odd-indexed characters
  // Write your code here
//  print(oddString)
  
  // Print a newline
//  print()
}

printEvenAndOdd(string: "Hacker")

//for _ in 1...numStrings {
//  let inputString = readLine()!
//  printEvenAndOdd(string: inputString)
//}

