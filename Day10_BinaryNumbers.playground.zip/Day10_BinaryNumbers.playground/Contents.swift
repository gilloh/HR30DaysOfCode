import Foundation

func countConsecutiveOnesOfBinary(_ n: Int) -> Int {
  var result = 0
  var temp = 0 {
    willSet {
      result = newValue > result ? newValue : result
    }
  }
  for digit in String(n, radix: 2) {
    temp = digit == "1" ? temp + 1 : 0
  }
  return result
}

print(countConsecutiveOnesOfBinary(5))
print(countConsecutiveOnesOfBinary(13))
print(countConsecutiveOnesOfBinary(439))
