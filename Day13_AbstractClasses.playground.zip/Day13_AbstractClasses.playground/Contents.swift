import Foundation

class Book: NSObject {
  // ..
}

class MyBook: Book {
  let title: String
  let author: String
  let price: Int

  init(title: String, author: String, price: Int) {
    self.title = title
    self.author = author
    self.price = price
  }

  func display() {
    print("Title: \(title)")
    print("Author: \(author)")
    print("Price: \(price)")
  }
}


let book = MyBook(title: readLine()!, author: readLine()!, price: Int(readLine()!)!)
book.display()

//let myBook = MyBook(title: "sdssd", author: "sdsdsd", price: 12)
//myBook.display()

// C++ solution
//     class MyBook: Book{
//
//          public:
//              int price;
//              MyBook(string t, string a, int p): Book(t, a){
//                  price = p;
//              }
//          void display(){
//              std::cout << "Title: " << title << endl << "Author: " << author << endl << "Price: " << price;
//          }
//
//      };
