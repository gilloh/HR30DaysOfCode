import UIKit

var str = "Hello, playground"

var phoneBook = [String: Any]()


for _ in 1...n {
  let person = readLine()!.components(separatedBy: " ").map{ $0 }
  phoneBook[person[0]] = Int(person[1])!
}


print(phoneBook)
