import Foundation

/*
 * Define an ErrorType
 */
enum StringToIntTypecastingError: Error {
  case BadString
}


func stringToInt(inputString: String) throws -> Int {
  guard let retInt = Int(inputString) else {
    throw StringToIntTypecastingError.BadString
  }
  return retInt
}



try stringToInt(inputString: "123")
try stringToInt(inputString: "as")
