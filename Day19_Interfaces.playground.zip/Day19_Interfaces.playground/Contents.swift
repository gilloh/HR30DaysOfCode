import Foundation

protocol AdvancedArithmetic {
  func divisorSum(_ n: Int) -> Int;
}

class Calculator: AdvancedArithmetic {
  
  func divisorSum(_ n: Int) -> Int {
    var sum = n
    
    for i in 1 ..< n {
      sum += n%i == 0 ? i : 0
    }
    return sum
  }
}

let calc = Calculator()

calc.divisorSum(6)
