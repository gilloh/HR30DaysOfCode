import Foundation

func bubbleSort(a: [Int]) {
  var sA = a
  var sortedIndex = a.count
  var numberOfSwaps = 0
  
  repeat {
    var lastSwapIndex = 0
    for i in 1 ..< sortedIndex {
      if sA[i-1] > sA[i] {
        sA.swapAt(i, i-1)
        numberOfSwaps+=1
        lastSwapIndex = i
      }
    }
    sortedIndex = lastSwapIndex
  } while sortedIndex != 0
  
  print("Array is sorted in \(numberOfSwaps) swaps.")
  print("First Element: \(sA.first!)")
  print("Last Element: \(sA.last!)")
}

bubbleSort(a: [2, 3, 1])

